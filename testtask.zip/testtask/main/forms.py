from django import forms
from .models import *

from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from django.core import validators
from django.core.validators import FileExtensionValidator


class ClientForm(forms.ModelForm):
    name = forms.CharField(label = 'Имя', error_messages={'required': ''})
    last_name = forms.CharField(label = 'Фамилия', error_messages={'required': ''})
    phone = forms.CharField(label = 'Телефон', error_messages={'required': ''})
    email = forms.EmailField(label = 'Email', error_messages={'required': ''})

    class Meta:
        model = Client
        fields = ('name', 'last_name', 'phone', 'email',)


class CommentForm(forms.ModelForm):
    text = forms.CharField(label = '', widget=forms.widgets.Textarea())

    class Meta:
        model = Comment
        fields = ('text',)


class LoginForm(forms.Form):
	username = forms.CharField(label = 'Ваш никнейм')
	password = forms.CharField(label = 'Ваш пароль', widget=forms.PasswordInput)
