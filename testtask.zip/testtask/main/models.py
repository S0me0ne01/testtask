from django.db import models

from django.contrib.auth.models import User

from django.core.validators import MinValueValidator, MaxValueValidator, MinLengthValidator
from django.shortcuts import get_object_or_404
from django.http import Http404

from django.db.models.signals import pre_save, post_save, post_init
from django.contrib.auth.signals import user_logged_in
from django.dispatch import receiver

import datetime


class Manager(models.Model):
    user = models.OneToOneField(User, related_name='manager', on_delete=models.CASCADE)
    last_login = models.DateTimeField(auto_now_add = True, db_index = True)


@receiver(post_save, sender=User)
def create_user_manager(sender, instance, created, **kwargs):
    if created:
        Manager.objects.create(user=instance)


class Client(models.Model):
    name = models.CharField(max_length = 50)
    last_name = models.CharField(max_length = 50)
    phone = models.CharField(max_length=12, validators=[MinLengthValidator(11)])
    email = models.EmailField()
    published = models.DateTimeField(auto_now_add = True, db_index = True)

    def __str__(self):
        return self.name + ' ' + self.last_name


class Comment(models.Model):
    author = models.CharField(max_length = 50)
    text = models.CharField(max_length = 500)
    published = models.DateTimeField(auto_now_add = True, db_index = True)
    client = models.ForeignKey('Client', related_name = 'client', null = True, blank = True, on_delete = models.CASCADE)
