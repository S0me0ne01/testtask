from django.contrib import admin
from django.urls import path

from .views import *

from django.contrib.auth.views import LoginView, LogoutView

app_name = 'main'

urlpatterns = [
    #Authentication
    path('login/', user_login, name = 'login'),
    path('logout/', LogoutView.as_view(next_page='main:homepage', template_name = "logged_out.html"), name = 'logout'),
    #Homepage
    path('', homepage, name = 'homepage'),
    #Manager
    path('manager/', manager, name = 'manager'),
    path('detail/<str:client_id>/', detail, name = 'detail'),
    path('delete/<str:kind>/<str:object_id>/', delete, name = 'delete'),
]
