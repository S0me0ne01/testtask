from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.models import User, UserManager
from django.contrib.auth.forms import UserCreationForm

from .models import *
from django.db.models import F
from .forms import *

import time
import datetime
import requests
import telegram

from django.contrib.auth import authenticate, login
from django.contrib.auth.views import redirect_to_login
from django.contrib.auth.mixins import LoginRequiredMixin

from django.http import HttpResponseRedirect, HttpRequest, HttpResponseForbidden, HttpResponse, HttpResponseNotFound, Http404
from django.urls import reverse

from django.template import RequestContext

from django.core.paginator import Paginator
from django.core.mail import send_mail


def homepage(request):
    if request.user.is_staff:
        request.user.manager.last_login = datetime.datetime.now()
        request.user.save()

    if request.method == 'POST':
        cf = ClientForm(request.POST)
        if cf.is_valid():
            cf = cf.save(commit = False)
            cf.save()
            return HttpResponseRedirect(reverse('main:homepage', args = ()))
        else:
            context = {'form' : cf}
            return render(request, 'homepage.html', context)
    else:
        cf = ClientForm()
        context = {'form' : cf}
        return render(request, 'homepage.html', context)


def manager(request):
    if request.user.is_staff:
        if (request.user.manager.pk % 2 == 0):
            clients = Client.objects.annotate(odd=F('pk') % 2).filter(odd=True).order_by('-published')
        else:
            clients = Client.objects.annotate(odd=F('pk') % 2).filter(odd=False).order_by('-published')
        context = {'clients' : clients}
        return render(request, 'manager.html', context)
    else:
        return HttpResponseForbidden()


def detail(request, client_id):
    if request.user.is_staff:
        client = get_object_or_404(Client, id = client_id)
        comments = Comment.objects.filter(client = client).order_by('-published')

        if request.method == 'POST':
            cf = CommentForm(request.POST)
            if cf.is_valid():
                cf = cf.save(commit = False)
                cf.client = client
                cf.save()
                return redirect(request.META['HTTP_REFERER'])
            else:
                context = {'form' : cf, 'client' : client, 'comments' : comments}
                return render(request, 'detail.html', context)
        else:
            cf = CommentForm()
            context = {'form' : cf, 'client' : client, 'comments' : comments}
            return render(request, 'detail.html', context)
    else:
        return HttpResponseForbidden()


def delete(request, kind, object_id):
    if request.user.is_staff:
        if kind == 'client':
            client = get_object_or_404(Client, id = object_id)
            client.delete()
            return HttpResponseRedirect(reverse('main:manager', args = ()))
        elif kind == 'comment':
            comment = get_object_or_404(Comment, id = object_id)
            comment.delete()
            return redirect(request.META['HTTP_REFERER'])
        else:
            return HttpResponseNotFound()
    else:
        return HttpResponseForbidden()


def user_login(request):
    if request.method == 'POST':
        lf = LoginForm(request.POST)
        if lf.is_valid():
            cd = lf.cleaned_data
            user = authenticate(username=cd['username'], password=cd['password'])
            if user is not None:
                if user.is_active:
                    login(request, user)
                    return HttpResponseRedirect(reverse('main:manager', args = ()))
                else:
                    return HttpResponse('Ошибка аккаунта')
            else:
                return HttpResponse('Некорректные данные')
        else:
            context = {'form' : lf}
            return render(request, 'login.html', context)
    else:
        lf = LoginForm()
        context = {'form' : lf}
        return render(request, 'login.html', context)
